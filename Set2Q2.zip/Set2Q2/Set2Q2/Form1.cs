﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Set2Q2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            fillc();
            fillc2();
        }

        void fillc()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Lenovo\Documents\database_connection1.mdf;Integrated Security=True;Connect Timeout=30");
            String q = "select pro_type from seasons";
            SqlCommand cmd = new SqlCommand(q,con);
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            while(sdr.Read())
            {
                comboBox1.Items.Add(sdr[0].ToString());
            }
            con.Close();

        }
        int id;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Lenovo\Documents\database_connection1.mdf;Integrated Security=True;Connect Timeout=30");
            String q = "select pro_id from seasons where pro_type = @pt";
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@pt",comboBox1.SelectedItem);   
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                id = Convert.ToInt32(sdr[0]);
            }
            con.Close();
            MessageBox.Show(id.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Lenovo\Documents\database_connection1.mdf;Integrated Security=True;Connect Timeout=30");
            String q = "insert into pro_info values(@nm,@pr,@q,@pid)";
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@nm", textBox1.Text);
            cmd.Parameters.AddWithValue("@pr", textBox2.Text);
            cmd.Parameters.AddWithValue("@q", textBox3.Text);
            cmd.Parameters.AddWithValue("@pid", id);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Data Inserted Successfully");
            fillc2();
        }

        void fillc2()
        {
            comboBox2.Items.Clear();
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Lenovo\Documents\database_connection1.mdf;Integrated Security=True;Connect Timeout=30");
            String q = "select Sub_Category from pro_info";
            SqlCommand cmd = new SqlCommand(q, con);
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                comboBox2.Items.Add(sdr[0].ToString());
            }
            con.Close();         
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Lenovo\Documents\database_connection1.mdf;Integrated Security=True;Connect Timeout=30");
            String q = "select * from pro_info where sub_category = '" + Convert.ToInt32(comboBox2.SelectedItem) + "'";
            SqlDataAdapter sda = new SqlDataAdapter(q,con);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Lenovo\Documents\database_connection1.mdf;Integrated Security=True;Connect Timeout=30");
            String q = "update seasons set pro_type = @nm where pro_id = @id";
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@nm", textBox1.Text);
            cmd.Parameters.AddWithValue("@id", id);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Data Updated Successfully");
        }
    }
}
