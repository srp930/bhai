﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace q2_set1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            cfill();
            cfill1();
        }
        int j;
        public void cfill()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\set1.mdf;Integrated Security=True;Connect Timeout=30");
            string q = "select season_type from seasons";
            SqlCommand cmd = new SqlCommand(q, con);
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                comboBox1.Items.Add(sdr[0].ToString());
            }

        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\set1.mdf;Integrated Security=True;Connect Timeout=30");
            string q = "select id from seasons where season_type=@type";
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@type", comboBox1.SelectedItem.ToString());
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            j = Convert.ToInt32(sdr[0]);
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\set1.mdf;Integrated Security=True;Connect Timeout=30");
            string q = "insert into customer values(@id,@name,@state,@email,@no,@season_type)";
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@id", txt_id.Text);
            cmd.Parameters.AddWithValue("@name", txt_name.Text);
            cmd.Parameters.AddWithValue("@state", txt_state.Text);
            cmd.Parameters.AddWithValue("@no", txt_number.Text);
            cmd.Parameters.AddWithValue("@email", txt_email.Text);
            cmd.Parameters.AddWithValue("@season_type", Convert.ToInt32(j));
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("data insert");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\set1.mdf;Integrated Security=True;Connect Timeout=30");
            string q = "select * from customer";
            SqlDataAdapter sda = new SqlDataAdapter(q, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource= dt;
        }
        public void cfill1()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\set1.mdf;Integrated Security=True;Connect Timeout=30");
            string q = "select id from customer";
            SqlCommand cmd = new SqlCommand(q, con);
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                comboBox2.Items.Add(sdr[0].ToString());
            }

        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\set1.mdf;Integrated Security=True;Connect Timeout=30");
            string q = "select * from customer where Id = '"+comboBox2.SelectedItem.ToString()+"'";
            SqlDataAdapter sda = new SqlDataAdapter(q, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView2.DataSource = dt;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DELL\Documents\set1.mdf;Integrated Security=True;Connect Timeout=30");
            string q = "update customer set season_id=@season_type where Id=@id";
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@id", txt_id.Text);
            cmd.Parameters.AddWithValue("@season_type", Convert.ToInt32(j));
            
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("data updated");
        }
    }
}
